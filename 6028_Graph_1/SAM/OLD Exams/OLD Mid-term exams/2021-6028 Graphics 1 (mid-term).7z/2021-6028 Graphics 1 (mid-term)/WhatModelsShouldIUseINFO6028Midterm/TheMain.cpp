#include <iostream>
#include <fstream>
#include <string>
#include <time.h>
#include <sstream>

using namespace std;

std::ofstream theFile;

void print(std::string theText, bool newLine = false)
{
	theFile << theText;
	cout << theText;

	if (newLine)
	{
		theFile << endl;
		cout << endl;
	}
	return;
}

std::string intToString(unsigned int theInt)
{
	std::stringstream ss2019Sucked;
	ss2019Sucked << theInt;
	return ss2019Sucked.str();
}

int randBetweenRange(int min, int max)
{
	int output = min + (rand() % static_cast<int>(max - min + 1));
	return output;
}

std::string genRandID(void)
{
	std::stringstream ssRandID;

	unsigned int numDigits = rand() % 5 + 10;
	for ( unsigned int count = 0; count != numDigits; count++ )
	{
		// 48 to 57
		// 65 to 90
		// 97 to 122
		bool bKeepLooking = true;
		unsigned char digit = 0;
		while ( bKeepLooking )
		{
			if ( rand() % 10 < 7 )
			{
				// Pick number
				digit = rand() % 128;
				if ( ( digit >= 48 && digit <= 57 ) )
				{
					bKeepLooking = false;
				}
			}
			else
			{	// Pick letter
				digit = rand() % 128;
				if ( ( digit >= 65 && digit <= 90 ) ||
					 ( digit >= 97 && digit <= 122 ) )
				{
					bKeepLooking = false;
				}
			}
		}// while ( bKeepLooking )

		ssRandID << (char)digit;

	}

	return ssRandID.str();
}

std::string genCoridor(unsigned int SN)
{
	// Reset seed to student number
	srand(SN);

	print("Your corridor has the following curved wall sections:", true);
	print("(so SM_Env_Wall_Curved_xx model)", true);
	print("", true);

	for (unsigned int count = 0; count < 4; count++)
	{
		print("Section ");
		print(intToString(count));
		print(" : ");
		print("left: ");
		print(intToString(randBetweenRange(1, 5)));
		print("  right: ");
		print(intToString(randBetweenRange(1, 5)), true);
	}
	print("", true);

	return "";
}
std::string genProps(unsigned int SN)
{
	// Reset seed to student number
	srand(SN);

	print("Add the following props to your hangar:", true);
	print("", true);

	for (unsigned int count = 0; count < 10; count++)
	{
		int prop = randBetweenRange(0, 32);
	
		switch (prop)
		{
		case 0:	print("SM_Prop_Scales_01", true); break;
		case 1:	print("SM_Prop_Server_01", true); break;
		case 2:	print("SM_Prop_Server_02", true); break;
		case 3:	print("SM_Prop_Server_03", true); break;
		case 4:	print("SM_Prop_Cart_01", true); break;
		case 5:	print("SM_Prop_Plants_05", true); break;
		case 6:	print("SM_Prop_Plants_04", true); break;
		case 7:	print("SM_Prop_Plants_03", true); break;
		case 8:	print("SM_Prop_Plants_02", true); break;
		case 9:	print("SM_Prop_Plants_01", true); break;
		case 10:	print("SM_Prop_Lockers_01", true); break;
		case 11:	print("SM_Prop_Lockers_02", true); break;
		case 12:	print("SM_Prop_Lockers_03", true); break;
		case 13:	print("SM_Prop_Lockers_04", true); break;
		case 14:	print("SM_Prop_Lockers_05", true); break;
		case 15:	print("SM_Prop_ServerRack_01", true); break;
		case 16:	print("SM_Prop_Sign_01", true); break;
		case 17:	print("SM_Prop_StepLadder_01", true); break;
		case 18:	print("SM_Prop_3DPrinter_01", true); break;
		case 19:	print("SM_Prop_Table_01", true); break;
		case 20:	print("SM_Prop_Treadmill_01", true); break;
		case 21:	print("SM_Prop_Trolley_01", true); break;
		case 22:	print("SM_Prop_Rocket_01", true); break;
		case 23:	print("SM_Prop_Phone_01", true); break;
		case 24:	print("SM_Prop_Monitor_04", true); break;
		case 25:	print("SM_Prop_Monitor_03", true); break;
		case 26:	print("SM_Prop_Monitor_02", true); break;
		case 27:	print("SM_Prop_Monitor_01", true); break;
		case 28:	print("SM_Prop_Lockers_01", true); break;
		case 29:	print("SM_Prop_SwivelChair_01", true); break;
		case 30:	print("SM_Prop_SwivelChair_02", true); break;
		case 31:	print("SM_Prop_SwivelChair_03", true); break;
		default:	print("SM_Prop_SwivelChair_04", true); break;
		}
		

	}//for (unsigned int count = 0; count < 10; count++)


	print("", true);
		
		

	return "";
}

int main()
{

	cout << "Welcome to the INFO-6028 midterm exam thingy." << endl;
	cout << endl;
	cout << "What's your student number, student? ";

	unsigned int SN = 0;
	cin >> SN;

	cout << endl;
	cout << "You entered: " << SN << endl;
	cout << endl;
	cout << "If that's wrong, please exit the program and start again." << endl;
	cout << "(and maybe get it right this time)" << std::endl;
	cout << endl;

	srand(time(NULL));

	std::stringstream ssLogFileName;
	ssLogFileName << "INFO-6028_midterm_log_" << genRandID() << rand() << ".log";

	theFile.open(ssLogFileName.str().c_str(), std::fstream::out);
	if (!theFile.is_open())
	{
		cout << "Error: Couldn't open file." << endl;
		cout << "Be sure to run this in a folder with write permissions" << endl;
		cout << "Exiting" << endl;
		return -1;
	}
	
	print("Log file opened", true);
	print("Student number: ", false);
	print(intToString(SN), true);
	print("Key#2: ", false);
	print(genRandID(), true);
	print("", true);

	bool bKeepGoing = true;

	// Reset seed to student number
	srand(SN);

	do
	{
		// Main menu
		cout << "Main menu" << endl;
		cout << endl;
		cout << "1. What models do I use for the corridor?" << endl;
		cout << "2. List my props I need." << endl;
		cout << "3. Exit" << endl;
		cout << endl;

		int choice = 0;
		cin >> choice;

		switch (choice)
		{
		case 1:
			print(genCoridor(SN));
			break;
		case 2:
			genProps(SN);
			break;
		case 3:
			bKeepGoing = false;
			break;
		}

	} while (bKeepGoing);

	theFile.close();

	return 0;
}
